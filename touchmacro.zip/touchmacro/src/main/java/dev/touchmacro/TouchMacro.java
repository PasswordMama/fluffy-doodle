package dev.touchmacro;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class TouchMacro implements ClientModInitializer {
    private final boolean[] held = new boolean[BindConfig.NAMES.length];

    @Override
    public void onInitializeClient() {
        BindConfig.load();

        ClientTickEvents.START_CLIENT_TICK.register(MacroManager::startTick);
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            MacroManager.endTick(c);
            pollBinds(c);
        });

        // "Macros" button on the pause menu (works on touch, no keyboard needed)
        ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Macros"),
                        b -> client.setScreen(new MacroScreen())).dimensions(6, 6, 90, 24).build());
            }
        });

        // Chat commands: /macro gui|record|stop|play|loop|save <n>|load <n>
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("macro")
                .then(ClientCommandManager.literal("gui").executes(ctx -> {
                    MinecraftClient c = ctx.getSource().getClient();
                    c.send(() -> c.setScreen(new MacroScreen()));
                    return 1;
                }))
                .then(ClientCommandManager.literal("record").executes(ctx -> {
                    MacroManager.startRecording(ctx.getSource().getClient());
                    return 1;
                }))
                .then(ClientCommandManager.literal("stop").executes(ctx -> {
                    MacroManager.stopAll(ctx.getSource().getClient());
                    return 1;
                }))
                .then(ClientCommandManager.literal("play").executes(ctx -> {
                    MacroManager.startPlayback(ctx.getSource().getClient());
                    return 1;
                }))
                .then(ClientCommandManager.literal("loop").executes(ctx -> {
                    MacroManager.loop = !MacroManager.loop;
                    ctx.getSource().sendFeedback(Text.literal("Loop: " + (MacroManager.loop ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.literal("save")
                    .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
                        boolean ok = MacroManager.save(StringArgumentType.getString(ctx, "name"));
                        ctx.getSource().sendFeedback(Text.literal(ok ? "Saved." : "Nothing to save."));
                        return ok ? 1 : 0;
                    })))
                .then(ClientCommandManager.literal("load")
                    .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
                        boolean ok = MacroManager.load(StringArgumentType.getString(ctx, "name"));
                        ctx.getSource().sendFeedback(Text.literal(ok ? "Loaded." : "Not found."));
                        return ok ? 1 : 0;
                    })))
            ));
    }

    private void pollBinds(MinecraftClient c) {
        if (c.player == null || c.getWindow() == null) return;
        boolean allowed = c.currentScreen == null;
        long handle = c.getWindow().getHandle();
        for (int i = 0; i < held.length; i++) {
            int key = BindConfig.keys[i];
            boolean down = allowed && key > 0 && GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            if (down && !held[i]) fire(i, c);
            held[i] = down;
        }
    }

    private void fire(int i, MinecraftClient c) {
        switch (i) {
            case 0 -> c.setScreen(new MacroScreen());
            case 1 -> {
                if (MacroManager.state == MacroManager.State.RECORDING) MacroManager.stopRecording(c);
                else MacroManager.startRecording(c);
            }
            case 2 -> {
                if (MacroManager.state == MacroManager.State.PLAYING) MacroManager.stopPlayback(c);
                else MacroManager.startPlayback(c);
            }
        }
    }
}
