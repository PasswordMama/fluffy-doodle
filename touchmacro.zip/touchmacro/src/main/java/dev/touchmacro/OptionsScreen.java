package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class OptionsScreen extends PinkScreen {
    private static final int PAD = 12, GAP = 6, ROW = 22;
    private final Screen parent;
    private int x0, innerW;

    public OptionsScreen(Screen parent) {
        super(Text.literal("Record / Replay Options"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int rows = (BindConfig.TOGGLE_NAMES.length + 1) / 2;
        layoutPanel(360, PAD + 26 + rows * (ROW + GAP) + ROW + PAD);
        x0 = px + PAD;
        innerW = pw - PAD * 2;
        int bw = (innerW - GAP) / 2;
        int y = py + PAD + 26;
        for (int i = 0; i < BindConfig.TOGGLE_NAMES.length; i++) {
            final int idx = i;
            int x = x0 + (i % 2) * (bw + GAP);
            if (i > 0 && i % 2 == 0) y += ROW + GAP;
            PinkButton b = new PinkButton(x, y, bw, ROW, Text.literal(BindConfig.TOGGLE_NAMES[i]),
                    BindConfig.toggles[i], btn -> {
                BindConfig.toggles[idx] = !BindConfig.toggles[idx];
                BindConfig.save();
                PinkButton pb = (PinkButton) btn;
                pb.primary = BindConfig.toggles[idx];
                pb.sw = BindConfig.toggles[idx];
            });
            b.sw = BindConfig.toggles[i];
            addDrawableChild(b);
        }
        y += ROW + GAP;
        addDrawableChild(new PinkButton(x0, y, innerW, ROW, Text.literal("Done"), true, b ->
                this.client.setScreen(parent)));
    }

    @Override
    protected void drawPanel(DrawContext ctx) {
        Ui.left(ctx, Text.literal("Record / Replay").formatted(Formatting.BOLD), x0, py + PAD + 2, 0xFFFFFFFF);
        Ui.left(ctx, Text.literal("Applies to recording and replay"), x0, py + PAD + 13, 0xFFFFE3F0);
    }

    @Override
    public void close() { this.client.setScreen(parent); }
}
