package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class MacroScreen extends Screen {
    private TextFieldWidget nameField;
    private ButtonWidget loopButton;
    private List<String> names = new ArrayList<>();
    private int sel = 0;
    private String status = "";

    public MacroScreen() { super(Text.literal("TouchMacro")); }

    @Override
    protected void init() {
        names = MacroManager.list();
        if (sel >= names.size()) sel = 0;

        int cx = this.width / 2;
        int w = 150, h = 24, gap = 4;
        int y = Math.max(20, this.height / 2 - 105);
        int lx = cx - w - gap / 2, rx = cx + gap / 2;

        // Row 1: record / stop
        addDrawableChild(ButtonWidget.builder(Text.literal("● Record"), b -> {
            this.client.setScreen(null);
            MacroManager.startRecording(this.client);
        }).dimensions(lx, y, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("■ Stop"), b -> {
            MacroManager.stopAll(this.client);
            status = "Stopped.";
        }).dimensions(rx, y, w, h).build());

        // Row 2: play / loop
        y += h + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("▶ Play"), b -> {
            this.client.setScreen(null);
            MacroManager.startPlayback(this.client);
        }).dimensions(lx, y, w, h).build());
        loopButton = ButtonWidget.builder(loopLabel(), b -> {
            MacroManager.loop = !MacroManager.loop;
            b.setMessage(loopLabel());
        }).dimensions(rx, y, w, h).build();
        addDrawableChild(loopButton);

        // Row 3: name + save
        y += h + gap + 6;
        nameField = new TextFieldWidget(this.textRenderer, lx, y, w, h, Text.literal("name"));
        nameField.setMaxLength(32);
        String def = MacroManager.currentName.isEmpty() || MacroManager.currentName.startsWith("(")
                ? "macro" + (names.size() + 1) : MacroManager.currentName;
        nameField.setText(def);
        addDrawableChild(nameField);
        addDrawableChild(ButtonWidget.builder(Text.literal("💾 Save"), b -> {
            boolean ok = MacroManager.save(nameField.getText());
            status = ok ? "Saved as " + MacroManager.sanitize(nameField.getText()) : "Nothing to save.";
            names = MacroManager.list();
        }).dimensions(rx, y, w, h).build());

        // Row 4: pick macro  < name >
        y += h + gap + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("◀"), b -> {
            if (!names.isEmpty()) sel = (sel - 1 + names.size()) % names.size();
        }).dimensions(lx, y, 40, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("▶"), b -> {
            if (!names.isEmpty()) sel = (sel + 1) % names.size();
        }).dimensions(rx + w - 40, y, 40, h).build());
        selectionY = y;

        // Row 5: load / delete
        y += h + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Load"), b -> {
            if (names.isEmpty()) { status = "No saved macros."; return; }
            status = MacroManager.load(names.get(sel)) ? "Loaded " + names.get(sel) : "Load failed.";
        }).dimensions(lx, y, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Delete"), b -> {
            if (names.isEmpty()) return;
            MacroManager.delete(names.get(sel));
            status = "Deleted " + names.get(sel);
            names = MacroManager.list();
            sel = 0;
        }).dimensions(rx, y, w, h).build());

        // Row 6: binds / done
        y += h + gap + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("Binds..."), b ->
                this.client.setScreen(new BindsScreen(this))).dimensions(lx, y, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b ->
                this.client.setScreen(null)).dimensions(rx, y, w, h).build());
    }

    private int selectionY = 0;

    private Text loopLabel() {
        return Text.literal("Loop: " + (MacroManager.loop ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 8, 0xFFFFFFFF);

        String sName = names.isEmpty() ? "(no saved macros)" : names.get(sel) + "  [" + (sel + 1) + "/" + names.size() + "]";
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(sName), cx, selectionY + 8, 0xFFFFFFFF);

        String cur = MacroManager.current == null ? "none"
                : MacroManager.currentName + " - " + MacroManager.current.length() + " ticks";
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Loaded: " + cur), cx, this.height - 24, 0xFFAAAAAA);
        if (!status.isEmpty())
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(status), cx, this.height - 12, 0xFFFFFF55);
    }

    @Override
    public boolean shouldPause() { return false; }
}
