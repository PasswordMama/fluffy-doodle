package dev.touchmacro.mixin;

import dev.touchmacro.MacroManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public class ClickSlotMixin {
    @Inject(method = "clickSlot", at = @At("HEAD"))
    private void touchmacro$onClick(int syncId, int slotId, int button, SlotActionType actionType,
                                    PlayerEntity player, CallbackInfo ci) {
        MacroManager.onClick(syncId, slotId, button, actionType);
    }
}
