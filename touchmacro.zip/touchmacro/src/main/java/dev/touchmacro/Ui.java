package dev.touchmacro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Drawing helpers for the "Rose Glass" look: rounded pills, glass panels, soft glow. */
public final class Ui {
    private Ui() {}

    /** 0..1, multiplies every alpha (used for the open fade-in). */
    public static float fade = 1f;

    public static int a(int c) {
        int al = Math.round(((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 255) + ((((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t));
        int r = (int) (((c1 >> 16) & 255) + ((((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t));
        int g = (int) (((c1 >> 8) & 255) + ((((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t));
        int b = (int) ((c1 & 255) + (((c2 & 255) - (c1 & 255)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int inset(int i, int h, int r) {
        if (r <= 0) return 0;
        double d;
        if (i < r) d = r - i - 0.5;
        else if (i >= h - r) d = i - (h - r) + 0.5;
        else return 0;
        return (int) Math.round(r - Math.sqrt(Math.max(0, (double) r * r - d * d)));
    }

    private static int clampR(int w, int h, int r) { return Math.max(0, Math.min(r, Math.min(w, h) / 2)); }

    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = clampR(w, h, r);
        int col = a(color);
        for (int i = 0; i < h; i++) {
            int ins = inset(i, h, r);
            c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
        }
    }

    public static void roundGradient(DrawContext c, int x, int y, int w, int h, int r, int top, int bottom) {
        r = clampR(w, h, r);
        for (int i = 0; i < h; i++) {
            int ins = inset(i, h, r);
            int col = a(lerp(top, bottom, h <= 1 ? 0f : i / (float) (h - 1)));
            c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
        }
    }

    public static void roundOutline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = clampR(w, h, r);
        int col = a(color);
        for (int i = 0; i < h; i++) {
            int ins = inset(i, h, r);
            if (i == 0 || i == h - 1) {
                c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
                continue;
            }
            int ref = i < r ? inset(i - 1, h, r) : (i >= h - r ? inset(i + 1, h, r) : ins);
            int run = Math.max(1, ref - ins);
            c.fill(x + ins, y + i, x + ins + run, y + i + 1, col);
            c.fill(x + w - ins - run, y + i, x + w - ins, y + i + 1, col);
        }
    }

    /** Soft round glow made of stacked translucent discs. */
    public static void glow(DrawContext c, int cx, int cy, int radius, int rgb, int alphaPerLayer) {
        for (int k = 0; k < 6; k++) {
            int rad = radius * (6 - k) / 6;
            roundRect(c, cx - rad, cy - rad, rad * 2, rad * 2, rad, (alphaPerLayer << 24) | (rgb & 0xFFFFFF));
        }
    }

    public static void drawBackground(DrawContext c, int w, int h) {
        c.fillGradient(0, 0, w, h / 2, a(0xCC241636), a(0xCC5B2A5E));
        c.fillGradient(0, h / 2, w, h, a(0xCC5B2A5E), a(0xE0C8508A));
        double t = System.currentTimeMillis() / 2600.0;
        glow(c, (int) (w * 0.12 + Math.sin(t) * 18), (int) (h * 0.15 + Math.cos(t * 0.8) * 12), 90, 0xFF7EB6, 7);
        glow(c, (int) (w * 0.9 + Math.cos(t * 0.9) * 18), (int) (h * 0.9 + Math.sin(t) * 12), 80, 0x9B6BFF, 7);
    }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        for (int k = 3; k >= 1; k--) roundRect(c, x - k, y - k + 3, w + 2 * k, h + 2 * k, 18 + k, 0x14000000);
        roundRect(c, x, y, w, h, 16, 0x30FFFFFF);
        roundOutline(c, x, y, w, h, 16, 0x66FFFFFF);
    }

    public static void centered(DrawContext c, Text t, int cx, int y, int color) {
        int col = a(color);
        if ((col >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, t, cx, y, col);
    }

    public static void left(DrawContext c, Text t, int x, int y, int color) {
        int col = a(color);
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, t, x, y, col);
    }
}
