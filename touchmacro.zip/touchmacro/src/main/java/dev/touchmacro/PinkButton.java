package dev.touchmacro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Rose Glass pill button: glass or pink gradient, smooth hover + press flash, optional switch. */
public class PinkButton extends ButtonWidget {
    public boolean primary;
    /** null = no switch; otherwise draws an on/off switch on the right. */
    public Boolean sw = null;
    private float hov = 0f;
    private final long[] flash;

    public PinkButton(int x, int y, int w, int h, Text msg, boolean primary, PressAction action) {
        this(x, y, w, h, msg, primary, action, new long[]{0L});
    }

    private PinkButton(int x, int y, int w, int h, Text msg, boolean primary, PressAction action, long[] flash) {
        super(x, y, w, h, msg, b -> { flash[0] = System.currentTimeMillis(); action.onPress(b); },
                DEFAULT_NARRATION_SUPPLIER);
        this.primary = primary;
        this.flash = flash;
    }

    @Override
    public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hov += (((this.isHovered() && this.active) ? 1f : 0f) - hov) * 0.3f;
        float fl = Math.max(0f, 1f - (System.currentTimeMillis() - flash[0]) / 240f);
        float lit = Math.max(hov, fl);

        int x = getX(), w = getWidth(), h = getHeight();
        int y = getY() - Math.round(hov);
        int r = h / 2;

        if (!this.active) {
            Ui.roundRect(ctx, x, y, w, h, r, 0x14FFFFFF);
            Ui.roundOutline(ctx, x, y, w, h, r, 0x26FFFFFF);
        } else if (primary) {
            Ui.roundRect(ctx, x + 1, y + 3, w - 2, h, r, 0x38E23A85); // glow
            Ui.roundGradient(ctx, x, y, w, h, r,
                    Ui.lerp(0xFFE23A85, 0xFFF55FA2, lit), Ui.lerp(0xFFC71F6E, 0xFFDC3A82, lit));
            Ui.roundOutline(ctx, x, y, w, h, r, 0x88FFFFFF);
        } else {
            Ui.roundRect(ctx, x, y, w, h, r, Ui.lerp(0x29FFFFFF, 0x4DFFFFFF, lit));
            Ui.roundOutline(ctx, x, y, w, h, r, Ui.lerp(0x4DFFFFFF, 0x99FFFFFF, lit));
        }

        int textColor = this.active ? 0xFFFFFFFF : 0x88FFFFFF;
        int textCx = x + w / 2;
        if (sw != null) {
            textCx = x + (w - 26) / 2;
            int sx = x + w - 28, sy = y + (h - 10) / 2;
            Ui.roundRect(ctx, sx, sy, 20, 10, 5, sw ? 0xFFFFFFFF : 0x66FFFFFF);
            Ui.roundRect(ctx, sw ? sx + 11 : sx + 1, sy + 1, 8, 8, 4, sw ? 0xFFD62A74 : 0xFFFFFFFF);
        }
        Ui.centered(ctx, getMessage(), textCx, y + (h - 8) / 2, textColor);
    }
}
