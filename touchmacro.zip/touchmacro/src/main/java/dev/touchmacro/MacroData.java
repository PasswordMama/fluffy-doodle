package dev.touchmacro;

/**
 * Saved macro. One frame per client tick plus a list of timed events.
 * flags bits: 0 fwd,1 back,2 left,3 right,4 jump,5 sneak,6 sprint,7 attack,8 use,9 drop,10 swap-hands
 * yaw == 9999 / slot == -1 mean "not recorded".
 * evType: 1 chat, 2 command, 3 click (player inv), 4 click (container), 5 open inventory, 6 close screen
 */
public class MacroData {
    public int version = 2;
    public int[] flags = new int[0];
    public float[] yaw = new float[0];
    public float[] pitch = new float[0];
    public int[] slot = new int[0];

    public int[] evTick;
    public int[] evType;
    public int[] evA;
    public int[] evB;
    public int[] evC;
    public String[] evS;

    public int length() { return flags == null ? 0 : flags.length; }
    public int evCount() { return evTick == null ? 0 : evTick.length; }
}
