package dev.touchmacro;

/** Saved macro. One entry per client tick. flags bits: 0 fwd,1 back,2 left,3 right,4 jump,5 sneak,6 sprint,7 attack,8 use */
public class MacroData {
    public int version = 1;
    public int[] flags = new int[0];
    public float[] yaw = new float[0];
    public float[] pitch = new float[0];
    public int[] slot = new int[0];

    public int length() { return flags == null ? 0 : flags.length; }
}
