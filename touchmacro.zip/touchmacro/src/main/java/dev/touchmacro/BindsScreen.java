package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class BindsScreen extends Screen {
    private final Screen parent;
    private int capturing = -1;
    private final ButtonWidget[] buttons = new ButtonWidget[BindConfig.NAMES.length];

    public BindsScreen(Screen parent) {
        super(Text.literal("TouchMacro Binds"));
        this.parent = parent;
    }

    private Text label(int i) {
        if (capturing == i) return Text.literal(BindConfig.NAMES[i] + ": > press a key <");
        int k = BindConfig.keys[i];
        String keyName = k <= 0 ? "Unbound"
                : InputUtil.Type.KEYSYM.createFromCode(k).getLocalizedText().getString();
        return Text.literal(BindConfig.NAMES[i] + ": " + keyName);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = Math.max(30, this.height / 2 - 60);
        for (int i = 0; i < buttons.length; i++) {
            final int idx = i;
            buttons[i] = ButtonWidget.builder(label(i), b -> {
                capturing = idx;
                refresh();
            }).dimensions(cx - 120, y, 240, 24).build();
            addDrawableChild(buttons[i]);
            y += 28;
        }
        y += 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> {
            BindConfig.save();
            this.client.setScreen(parent);
        }).dimensions(cx - 120, y, 240, 24).build());
    }

    private void refresh() {
        for (int i = 0; i < buttons.length; i++) buttons[i].setMessage(label(i));
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (capturing >= 0) {
            int key = input.key();
            // Escape unbinds, anything else binds
            BindConfig.keys[capturing] = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            capturing = -1;
            BindConfig.save();
            refresh();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Tap a bind, then press a key (Esc = unbind)"), this.width / 2, 24, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        BindConfig.save();
        this.client.setScreen(parent);
    }
}
