package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class BindsScreen extends PinkScreen {
    private static final int PAD = 12, GAP = 6, ROW = 22;
    private final Screen parent;
    private int capturing = -1;
    private final PinkButton[] buttons = new PinkButton[BindConfig.NAMES.length];
    private int x0;

    public BindsScreen(Screen parent) {
        super(Text.literal("TouchMacro Binds"));
        this.parent = parent;
    }

    private Text label(int i) {
        if (capturing == i) return Text.literal(BindConfig.NAMES[i] + ": press a key...");
        int k = BindConfig.keys[i];
        String keyName = k <= 0 ? "Unbound"
                : InputUtil.Type.KEYSYM.createFromCode(k).getLocalizedText().getString();
        return Text.literal(BindConfig.NAMES[i] + ": " + keyName);
    }

    @Override
    protected void init() {
        layoutPanel(320, PAD + 26 + buttons.length * (ROW + GAP) + ROW + PAD);
        x0 = px + PAD;
        int innerW = pw - PAD * 2;
        int y = py + PAD + 26;
        for (int i = 0; i < buttons.length; i++) {
            final int idx = i;
            buttons[i] = new PinkButton(x0, y, innerW, ROW, label(i), capturing == i, b -> {
                capturing = idx;
                refresh();
            });
            addDrawableChild(buttons[i]);
            y += ROW + GAP;
        }
        addDrawableChild(new PinkButton(x0, y, innerW, ROW, Text.literal("Done"), true, b -> {
            BindConfig.save();
            this.client.setScreen(parent);
        }));
    }

    private void refresh() {
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].setMessage(label(i));
            buttons[i].primary = capturing == i;
        }
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (capturing >= 0) {
            int key = input.key();
            BindConfig.keys[capturing] = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            capturing = -1;
            BindConfig.save();
            refresh();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    protected void drawPanel(DrawContext ctx) {
        Ui.left(ctx, Text.literal("Binds").formatted(Formatting.BOLD), x0, py + PAD + 2, 0xFFFFFFFF);
        Ui.left(ctx, Text.literal("Tap a bind, then press a key (Esc = unbind)"), x0, py + PAD + 13, 0xFFFFE3F0);
    }

    @Override
    public void close() {
        BindConfig.save();
        this.client.setScreen(parent);
    }
}
