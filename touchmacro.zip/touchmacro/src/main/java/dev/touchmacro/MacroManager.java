package dev.touchmacro;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public final class MacroManager {
    public enum State { IDLE, RECORDING, PLAYING }

    public static State state = State.IDLE;
    public static boolean loop = false;
    public static MacroData current = null;
    public static String currentName = "";

    private static final Gson GSON = new Gson();
    private static final int ATTACK_BIT = 7, USE_BIT = 8;

    private static final class Frame { int f; float yaw, pitch; int slot; }
    private static final List<Frame> rec = new ArrayList<>();
    private static int playIndex = 0;
    private static int prevFlags = 0;

    // ---- wander (random 2-block walk out and back every N loops) ----
    private static final double WANDER_DIST = 2.0;
    private static int loopCount = 0;
    private static int wanderPhase = 0; // 0 none, 1 going out, 2 coming back
    private static int wanderTicks = 0;
    private static double sx, sz, tx, tz;

    private MacroManager() {}

    private static KeyBinding[] keys(GameOptions o) {
        return new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey,
                o.jumpKey, o.sneakKey, o.sprintKey, o.attackKey, o.useKey};
    }

    private static void msg(MinecraftClient c, String s) {
        if (c.player != null) c.player.sendMessage(Text.literal(s), true);
    }

    private static void releaseAll(MinecraftClient c) {
        for (KeyBinding k : keys(c.options)) k.setPressed(false);
    }

    // ---------- recording ----------
    public static void startRecording(MinecraftClient c) {
        if (c.player == null) return;
        stopAll(c);
        rec.clear();
        state = State.RECORDING;
        msg(c, "● Recording...");
    }

    public static void stopRecording(MinecraftClient c) {
        if (state != State.RECORDING) return;
        state = State.IDLE;
        MacroData d = new MacroData();
        int n = rec.size();
        d.flags = new int[n]; d.yaw = new float[n]; d.pitch = new float[n]; d.slot = new int[n];
        for (int i = 0; i < n; i++) {
            Frame f = rec.get(i);
            d.flags[i] = f.f; d.yaw[i] = f.yaw; d.pitch[i] = f.pitch; d.slot[i] = f.slot;
        }
        rec.clear();
        current = d;
        currentName = "(unsaved)";
        msg(c, "Recorded " + n + " ticks (" + (n / 20) + "s). Open the GUI to save.");
    }

    // ---------- playback ----------
    public static void startPlayback(MinecraftClient c) {
        if (c.player == null || current == null || current.length() == 0) {
            msg(c, "Nothing to play. Record or load a macro first.");
            return;
        }
        stopAll(c);
        playIndex = 0;
        prevFlags = 0;
        loopCount = 0;
        wanderPhase = 0;
        state = State.PLAYING;
    }

    public static void stopPlayback(MinecraftClient c) {
        if (state != State.PLAYING) return;
        state = State.IDLE;
        wanderPhase = 0;
        releaseAll(c);
        msg(c, "Playback stopped.");
    }

    public static void stopAll(MinecraftClient c) {
        if (state == State.RECORDING) stopRecording(c);
        else if (state == State.PLAYING) stopPlayback(c);
    }

    // ---------- tick hooks ----------
    public static void startTick(MinecraftClient c) {
        if (state != State.PLAYING) return;
        ClientPlayerEntity p = c.player;
        if (p == null) { state = State.IDLE; return; }
        if (c.currentScreen != null) return; // pause while any screen is open

        if (wanderPhase != 0) { wanderTick(c, p); return; }

        if (playIndex >= current.length()) {
            if (loop) {
                playIndex = 0;
                loopCount++;
                int n = BindConfig.wanderEvery;
                if (n > 0 && loopCount % n == 0) {
                    beginWander(c, p);
                    wanderTick(c, p);
                    return;
                }
            } else { stopPlayback(c); return; }
        }
        int i = playIndex++;
        int f = current.flags[i];
        KeyBinding[] ks = keys(c.options);
        for (int b = 0; b < ks.length; b++) {
            boolean down = ((f >> b) & 1) != 0;
            boolean was = ((prevFlags >> b) & 1) != 0;
            ks[b].setPressed(down);
            if (down && !was && (b == ATTACK_BIT || b == USE_BIT)) {
                // registers a "click" so single hits/placements work, not only held input
                KeyBinding.onKeyPressed(InputUtil.fromTranslationKey(ks[b].getBoundKeyTranslationKey()));
            }
        }
        prevFlags = f;
        p.setYaw(current.yaw[i]);
        p.setPitch(current.pitch[i]);
        int s = current.slot[i];
        if (s >= 0 && s < 9) p.getInventory().setSelectedSlot(s);
        if (i % 20 == 0) msg(c, "▶ Playing " + i + "/" + current.length() + (loop ? " (loop)" : ""));
    }

    private static void beginWander(MinecraftClient c, ClientPlayerEntity p) {
        sx = p.getX();
        sz = p.getZ();
        double a = Math.random() * Math.PI * 2;
        tx = sx + Math.cos(a) * WANDER_DIST;
        tz = sz + Math.sin(a) * WANDER_DIST;
        wanderPhase = 1;
        wanderTicks = 0;
        releaseAll(c);
        prevFlags = 0;
    }

    private static void endWander(MinecraftClient c) {
        wanderPhase = 0;
        wanderTicks = 0;
        releaseAll(c);
        prevFlags = 0;
        playIndex = 0;
    }

    private static void wanderTick(MinecraftClient c, ClientPlayerEntity p) {
        wanderTicks++;
        KeyBinding[] ks = keys(c.options);
        for (KeyBinding k : ks) k.setPressed(false);

        double gx = wanderPhase == 1 ? tx : sx;
        double gz = wanderPhase == 1 ? tz : sz;
        double dx = gx - p.getX(), dz = gz - p.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (wanderTicks > 300) { // stuck/blocked: give up and carry on
            endWander(c);
            return;
        }

        if (dist < 0.12) {
            if (wanderPhase == 1) {
                wanderPhase = 2;
                wanderTicks = 0;
                return;
            }
            // back home: snap onto the exact start spot and resume the macro
            p.setPosition(sx, p.getY(), sz);
            p.setVelocity(0, p.getVelocity().y, 0);
            endWander(c);
            return;
        }

        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        p.setYaw(yaw);
        p.setPitch(0f);
        ks[0].setPressed(true);                          // forward
        if (dist < 0.8) ks[5].setPressed(true);          // sneak to slow down near target
        if (p.horizontalCollision && p.isOnGround()) ks[4].setPressed(true); // hop over 1-block steps
        if (wanderTicks % 20 == 0) msg(c, "↔ Wandering " + (wanderPhase == 1 ? "out" : "back"));
    }

    public static void endTick(MinecraftClient c) {
        if (state != State.RECORDING) return;
        ClientPlayerEntity p = c.player;
        if (p == null) { stopRecording(c); return; }
        if (c.currentScreen != null) return; // don't record while a menu is open
        KeyBinding[] ks = keys(c.options);
        Frame fr = new Frame();
        for (int b = 0; b < ks.length; b++) if (ks[b].isPressed()) fr.f |= 1 << b;
        fr.yaw = p.getYaw();
        fr.pitch = p.getPitch();
        fr.slot = p.getInventory().getSelectedSlot();
        rec.add(fr);
        if (rec.size() % 20 == 0) msg(c, "● REC " + rec.size() + " ticks");
    }

    // ---------- storage ----------
    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("touchmacro").resolve("macros");
    }

    public static String sanitize(String n) {
        String s = n == null ? "" : n.replaceAll("[^A-Za-z0-9_-]", "_");
        return s.isEmpty() ? "macro" : s;
    }

    public static boolean save(String name) {
        if (current == null || current.length() == 0) return false;
        try {
            name = sanitize(name);
            Files.createDirectories(dir());
            Files.writeString(dir().resolve(name + ".json"), GSON.toJson(current));
            currentName = name;
            return true;
        } catch (Exception e) {
            System.err.println("[TouchMacro] save failed: " + e);
            return false;
        }
    }

    public static boolean load(String name) {
        try {
            Path f = dir().resolve(sanitize(name) + ".json");
            MacroData d = GSON.fromJson(Files.readString(f), MacroData.class);
            if (d == null || d.length() == 0) return false;
            current = d;
            currentName = sanitize(name);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(dir().resolve(sanitize(name) + ".json"));
        } catch (Exception e) {
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try {
            if (!Files.isDirectory(dir())) return out;
            try (Stream<Path> s = Files.list(dir())) {
                s.map(p -> p.getFileName().toString())
                        .filter(n -> n.endsWith(".json"))
                        .forEach(n -> out.add(n.substring(0, n.length() - 5)));
            }
        } catch (Exception ignored) {}
        Collections.sort(out);
        return out;
    }
}
