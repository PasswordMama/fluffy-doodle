package dev.touchmacro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;

public class BindConfig {
    public static final String[] NAMES = {"Open GUI", "Record / Stop", "Play / Stop"};
    /** GLFW key codes, -1 = unbound. */
    public static int[] keys = {GLFW.GLFW_KEY_F8, GLFW.GLFW_KEY_F9, GLFW.GLFW_KEY_F10};

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static class Store { int[] keys; }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("touchmacro").resolve("binds.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Store s = GSON.fromJson(Files.readString(f), Store.class);
                if (s != null && s.keys != null && s.keys.length == keys.length) keys = s.keys;
            }
        } catch (Exception e) {
            System.err.println("[TouchMacro] could not load binds: " + e);
        }
    }

    public static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Store s = new Store();
            s.keys = keys;
            Files.writeString(f, GSON.toJson(s));
        } catch (Exception e) {
            System.err.println("[TouchMacro] could not save binds: " + e);
        }
    }
}
