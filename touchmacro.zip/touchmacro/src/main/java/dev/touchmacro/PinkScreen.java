package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Base for all TouchMacro screens: Rose Glass background + panel + fade-in. */
public abstract class PinkScreen extends Screen {
    protected int px, py, pw, ph;
    private final long opened = System.currentTimeMillis();

    protected PinkScreen(Text title) { super(title); }

    protected void layoutPanel(int panelW, int panelH) {
        pw = Math.min(this.width - 12, panelW);
        ph = panelH;
        px = (this.width - pw) / 2;
        py = Math.max(4, (this.height - ph) / 2);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Ui.drawBackground(ctx, this.width, this.height);
        Ui.panel(ctx, px, py, pw, ph);
        drawPanel(ctx);
    }

    /** Drawn on the panel, under the widgets. */
    protected void drawPanel(DrawContext ctx) {}

    /** Drawn after the widgets. */
    protected void drawOverlay(DrawContext ctx) {}

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float t = Math.min(1f, (System.currentTimeMillis() - opened) / 260f);
        Ui.fade = 1f - (1f - t) * (1f - t);
        super.render(ctx, mouseX, mouseY, delta);
        drawOverlay(ctx);
        Ui.fade = 1f;
    }

    @Override
    public boolean shouldPause() { return false; }
}
