TouchMacro - Fabric 1.21.11 (client only)

BUILD ON PHONE (GitHub):
1. Make a new GitHub repo, upload ALL files from this folder (keep the folders, incl. .github/workflows/build.yml).
2. Repo > Actions > "Build" > Run workflow (it also runs on every push).
3. When it finishes, open the run > Artifacts > touchmacro-jar. Unzip it, put touchmacro-1.0.0.jar in your instance's mods folder.
   If the build fails, copy the red error lines and send them to Claude.

USE:
- Pause menu > "Macros" button (top-left), or chat: /macro gui
- Record: starts recording and closes the menu. Stop with your Record bind, /macro stop, or the pause-menu button.
- Save: type a name, tap Save. Pick saved macros with the arrows, tap Load, then Play.
- Loop toggles repeat.
- Binds...: tap a bind, press a key. Defaults F8 (GUI), F9 (record/stop), F10 (play/stop).
  On Zalith, map an on-screen control button to those keys in the control editor.
- Macros live in config/touchmacro/macros/*.json
- Commands: /macro gui|record|stop|play|loop|save <name>|load <name>
