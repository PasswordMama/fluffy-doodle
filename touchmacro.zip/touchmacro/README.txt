TouchMacro - Fabric 1.21.11 (client only)

BUILD ON PHONE (GitHub):
1. Make a new GitHub repo, upload ALL files from this folder (keep the folders, incl. .github/workflows/build.yml).
2. Repo > Actions > "Build" > Run workflow (it also runs on every push).
3. When it finishes, open the run > Artifacts > touchmacro-jar. Unzip it, put touchmacro-1.0.0.jar in your instance's mods folder.
   If the build fails, copy the red error lines and send them to Claude.

USE:
- Pause menu > "Macros" button (top-left), or chat: /macro gui
- Record: starts recording and closes the menu. Stop with your Record bind, /macro stop, or the pause-menu button.
- Save: type a name, tap Save. Pick saved macros with the arrows, tap Load, then Play.
- Loop toggles repeat.
- Binds...: tap a bind, press a key. Defaults F8 (GUI), F9 (record/stop), F10 (play/stop).
  On Zalith, map an on-screen control button to those keys in the control editor.
- Macros live in config/touchmacro/macros/*.json
- Commands: /macro gui|record|stop|play|loop|save <name>|load <name>

WANDER: in the GUI use - / + to set 'Wander every N loops' (0 = off). Needs Loop ON. Every N loops the player walks 2 blocks in a random direction, returns to the exact start spot, then the macro continues.

OPTIONS: GUI > Options toggles what is recorded AND replayed: Walk/Jump/Sneak, Mine/Attack, Use/Place, Camera look, Hotbar slot, Inventory & menus (open/close, every slot click incl. server command menus, drop, swap hands), Chat messages, Commands.
Menu clicks wait up to 10s for the menu to open. Creative-mode inventory is not supported.

STYLE: Rose Glass UI (pink glass panels, pill buttons, hover/press animation, fade-in).
